package com.videograb.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.videograb.app.ui.BrowserScreen
import com.videograb.app.ui.BrowserState
import com.videograb.app.ui.DownloadsScreen
import com.videograb.app.ui.LinkScreen
import com.videograb.app.ui.VideoGrabTheme

enum class Tab(val label: String) { BROWSER("Browser"), LINK("Paste link"), DOWNLOADS("Downloads") }

class MainActivity : ComponentActivity() {

    companion object {
        const val EXTRA_OPEN_DOWNLOADS = "open_downloads"
        private val URL_REGEX = Regex("""https?://\S+""")
    }

    // Shared with the UI: a link that came in from "Share", and which tab to show.
    private var incomingLink by mutableStateOf<String?>(null)
    private var currentTab by mutableStateOf(Tab.BROWSER)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        askForPermissions()
        handleIntent(intent)

        setContent {
            VideoGrabTheme {
                MainScreen(
                    tab = currentTab,
                    onTabChange = { currentTab = it },
                    incomingLink = incomingLink,
                    onIncomingHandled = { incomingLink = null },
                    onSendToLinkTab = { url ->
                        incomingLink = url
                        currentTab = Tab.LINK
                    },
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        if (intent.getBooleanExtra(EXTRA_OPEN_DOWNLOADS, false)) {
            currentTab = Tab.DOWNLOADS
        }
        if (intent.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            URL_REGEX.find(text)?.value?.let {
                incomingLink = it
                currentTab = Tab.LINK
            }
        }
    }

    private fun askForPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT <= 28) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }.filter {
            ContextCompat.checkSelfPermission(this, it) != android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())
    }
}

@Composable
private fun MainScreen(
    tab: Tab,
    onTabChange: (Tab) -> Unit,
    incomingLink: String?,
    onIncomingHandled: () -> Unit,
    onSendToLinkTab: (String) -> Unit,
) {
    // Created once, so the web page stays loaded when you switch tabs.
    val browserState = remember { BrowserState() }

    // Live download status, shown on every tab.
    val context = LocalContext.current
    val jobsFlow = remember { WorkManager.getInstance(context).getWorkInfosByTagFlow(Downloads.TAG) }
    val jobs by jobsFlow.collectAsStateWithLifecycle(initialValue = emptyList())
    val active = jobs.filter { !it.state.isFinished }
    val percents = active.filter { it.state == WorkInfo.State.RUNNING }
        .map { it.progress.getInt(Downloads.KEY_PROGRESS, -1) }.filter { it >= 0 }
    val overall = if (percents.isEmpty()) -1 else percents.average().toInt()

    Scaffold(
        bottomBar = {
            Column {
                if (active.isNotEmpty() && tab != Tab.DOWNLOADS) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth().clickable { onTabChange(Tab.DOWNLOADS) },
                    ) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text(
                                text = buildString {
                                    append(if (active.size == 1) Downloads.titleOf(active.first()) else "${active.size} downloads")
                                    if (overall >= 0) append(" · $overall%")
                                },
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            if (overall >= 0) {
                                LinearProgressIndicator(
                                    progress = { overall / 100f },
                                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                )
                            } else {
                                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))
                            }
                        }
                    }
                }
                NavigationBar {
                    Tab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { onTabChange(t) },
                            icon = {
                                val icon = when (t) {
                                    Tab.BROWSER -> Icons.Filled.Language
                                    Tab.LINK -> Icons.Filled.Link
                                    Tab.DOWNLOADS -> Icons.Filled.Download
                                }
                                if (t == Tab.DOWNLOADS && active.isNotEmpty()) {
                                    BadgedBox(badge = { Badge { Text(active.size.toString()) } }) {
                                        Icon(icon, contentDescription = null)
                                    }
                                } else {
                                    Icon(icon, contentDescription = null)
                                }
                            },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                Tab.BROWSER -> BrowserScreen(browserState, onSendPageToLinkTab = onSendToLinkTab)
                Tab.LINK -> LinkScreen(incomingLink, onIncomingHandled)
                Tab.DOWNLOADS -> DownloadsScreen()
            }
        }
    }
}
