package com.videograb.app

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class VideoGrabApp : Application() {

    /** Long-lived scope for app-wide background work (engine setup, updates). */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        Notifications.createChannels(this)
        AppSettings.load(this)
        // Unpacking the yt-dlp engine takes a few seconds the first time, so do it off the main thread.
        // A failure is shown on screen through Engine.state instead of crashing the app.
        appScope.launch { runCatching { Engine.ensureReady(this@VideoGrabApp) } }
        // Load the ad block list (and refresh it in the background if it's a week old).
        appScope.launch { runCatching { AdBlocker.init(this@VideoGrabApp) } }
    }
}
