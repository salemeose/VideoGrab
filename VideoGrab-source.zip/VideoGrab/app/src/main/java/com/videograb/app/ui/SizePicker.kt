package com.videograb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videograb.app.Quality
import java.util.Locale

/** Turns a byte count into "850 KB", "12.4 MB" or "1.2 GB". */
fun formatSize(bytes: Long?): String {
    if (bytes == null || bytes <= 0) return "Size unknown"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.US, "%.1f GB", gb)
        mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb.coerceAtLeast(1.0))
    }
}

/** The size groups shown in lists, biggest first. Small files on web pages are often ads or previews. */
enum class SizeGroup(val label: String) {
    LARGE("Large · over 100 MB"),
    MEDIUM("Medium · 10–100 MB"),
    SMALL("Small · under 10 MB"),
    UNKNOWN("Size unknown · streams and sites that don't say");

    companion object {
        fun of(bytes: Long?): SizeGroup = when {
            bytes == null || bytes <= 0 -> UNKNOWN
            bytes > 100L * 1024 * 1024 -> LARGE
            bytes >= 10L * 1024 * 1024 -> MEDIUM
            else -> SMALL
        }
    }
}

/** One row in a picker. */
data class PickItem(
    val key: String,
    val title: String,
    val detail: String,
    val sizeBytes: Long?,
    /** A frame already grabbed from the video, if any. */
    val thumbBitmap: android.graphics.Bitmap? = null,
    /** A link to a cover picture, used when there's no frame. */
    val thumbUrl: String? = null,
)

/** Builds the rows for a list: grouped by size, biggest first inside each group. */
private sealed interface ListRow {
    data class Header(val group: SizeGroup, val count: Int, val total: Long) : ListRow
    data class Item(val item: PickItem) : ListRow
}

private fun buildRows(items: List<PickItem>): List<ListRow> =
    items.groupBy { SizeGroup.of(it.sizeBytes) }
        .toSortedMap(compareBy { it.ordinal })
        .flatMap { (group, list) ->
            val sorted = list.sortedByDescending { it.sizeBytes ?: -1L }
            listOf<ListRow>(ListRow.Header(group, list.size, list.sumOf { it.sizeBytes ?: 0L })) + sorted.map { ListRow.Item(it) }
        }

/**
 * A size-grouped list with checkboxes. Tapping a group header selects or clears the whole group.
 * Used both for videos found behind a link and for files spotted in the browser.
 */
@Composable
fun GroupedPickList(
    items: List<PickItem>,
    selected: Set<String>,
    onSelectionChange: (Set<String>) -> Unit,
    modifier: Modifier = Modifier,
) {
    val rows = buildRows(items)
    LazyColumn(modifier) {
        items(rows, key = { row ->
            when (row) {
                is ListRow.Header -> "h_" + row.group.name
                is ListRow.Item -> "i_" + row.item.key
            }
        }) { row ->
            when (row) {
                is ListRow.Header -> {
                    val groupKeys = items.filter { SizeGroup.of(it.sizeBytes) == row.group }.map { it.key }.toSet()
                    val allOn = groupKeys.isNotEmpty() && selected.containsAll(groupKeys)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onSelectionChange(if (allOn) selected - groupKeys else selected + groupKeys) }
                            .padding(start = 4.dp, end = 8.dp, top = 10.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = allOn,
                            onCheckedChange = { onSelectionChange(if (allOn) selected - groupKeys else selected + groupKeys) },
                        )
                        Column(Modifier.weight(1f)) {
                            Text(row.group.label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary)
                            val total = if (row.total > 0) " · ${formatSize(row.total)} total" else ""
                            Text("${row.count} ${if (row.count == 1) "file" else "files"}$total",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                is ListRow.Item -> {
                    val on = row.item.key in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onSelectionChange(if (on) selected - row.item.key else selected + row.item.key) }
                            .padding(start = 16.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = on,
                            onCheckedChange = { onSelectionChange(if (on) selected - row.item.key else selected + row.item.key) },
                        )
                        VideoThumb(bitmap = row.item.thumbBitmap, url = row.item.thumbUrl)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(row.item.title, style = MaterialTheme.typography.bodyMedium, maxLines = 2,
                                overflow = TextOverflow.Ellipsis)
                            Text(row.item.detail, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(formatSize(row.item.sizeBytes).replace("Size unknown", "?"),
                            style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}

/**
 * Shown when a link holds several videos: pick some (or all), choose a quality, download.
 * Sizes are estimates for the best quality.
 */
@Composable
fun PickVideosDialog(
    title: String,
    items: List<PickItem>,
    onDismiss: () -> Unit,
    onDownload: (keys: Set<String>, quality: Quality) -> Unit,
) {
    var selected by remember { mutableStateOf(items.map { it.key }.toSet()) }
    var quality by remember { mutableStateOf(Quality.BEST) }
    val chosenBytes = items.filter { it.key in selected }.sumOf { it.sizeBytes ?: 0L }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                Text("${items.size} videos found", style = MaterialTheme.typography.bodySmall)
            }
        },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { selected = items.map { it.key }.toSet() }) { Text("Select all") }
                    TextButton(onClick = { selected = emptySet() }) { Text("Clear") }
                }
                GroupedPickList(
                    items = items,
                    selected = selected,
                    onSelectionChange = { selected = it },
                    modifier = Modifier.heightIn(max = 360.dp),
                )
                Row(Modifier.padding(top = 8.dp)) {
                    listOf(Quality.BEST to "Best", Quality.P720 to "720p", Quality.AUDIO to "MP3").forEach { (q, label) ->
                        FilterChip(
                            selected = quality == q,
                            onClick = { quality = q },
                            label = { Text(label) },
                            modifier = Modifier.padding(end = 8.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = selected.isNotEmpty(), onClick = { onDownload(selected, quality) }) {
                val size = if (chosenBytes > 0) " · ~${formatSize(chosenBytes)}" else ""
                Text("Download ${selected.size}$size")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
