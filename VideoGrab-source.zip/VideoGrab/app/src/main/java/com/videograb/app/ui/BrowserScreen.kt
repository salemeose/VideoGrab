package com.videograb.app.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import android.widget.Toast

/** A media file spotted while a page loaded. */
data class FoundMedia(val url: String, val kind: String, val pageUrl: String, val pageTitle: String)

private const val HOME_PAGE = "https://www.google.com"

// File types that are whole videos or playlists. Small stream pieces (.ts, .m4s) are skipped on purpose.
private val MEDIA_REGEX = Regex("""\.(mp4|m4v|webm|mov|mkv|m3u8|mpd|mp3|m4a)(\?|#|$)""", RegexOption.IGNORE_CASE)

/** Holds the WebView and what it found, so they survive switching tabs. */
class BrowserState {
    var webView: WebView? = null
    var address by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var loadingProgress by mutableStateOf(100)
    var canGoBack by mutableStateOf(false)
    val found = mutableStateListOf<FoundMedia>()

    fun load(input: String) {
        val text = input.trim()
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains('.') && !text.contains(' ') -> "https://$text"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(text, "UTF-8")
        }
        webView?.loadUrl(url)
    }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(context: android.content.Context, state: BrowserState): WebView =
    WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                state.address = url
                state.found.clear()
            }

            override fun onPageFinished(view: WebView, url: String) {
                state.pageTitle = view.title.orEmpty()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                state.address = url
                state.canGoBack = view.canGoBack()
            }

            // Every network request the page makes passes through here; we note the ones that are media.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                if (MEDIA_REGEX.containsMatchIn(url)) {
                    val kind = MEDIA_REGEX.find(url)!!.groupValues[1].lowercase()
                    view.post {
                        if (state.found.none { it.url == url }) {
                            state.found.add(FoundMedia(url, kind, view.url.orEmpty(), view.title.orEmpty()))
                        }
                    }
                }
                return null
            }
        }

        webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                state.loadingProgress = newProgress
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                state.pageTitle = title.orEmpty()
            }
        }

        // When a site offers a file download link, catch it too.
        setDownloadListener { url, _, _, _, _ ->
            post {
                if (state.found.none { it.url == url }) {
                    state.found.add(FoundMedia(url, "file", this.url.orEmpty(), this.title.orEmpty()))
                }
            }
        }

        loadUrl(HOME_PAGE)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(state: BrowserState, onSendPageToLinkTab: (String) -> Unit) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    var showSheet by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<FoundMedia?>(null) }

    BackHandler(enabled = state.canGoBack) { state.webView?.goBack() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { state.webView?.goBack() }, enabled = state.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            OutlinedTextField(
                value = state.address,
                onValueChange = { state.address = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search or type a web address") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    state.load(state.address)
                    focus.clearFocus()
                }),
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            IconButton(onClick = { state.webView?.reload() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload")
            }
            IconButton(onClick = { state.webView?.loadUrl(HOME_PAGE) }) {
                Icon(Icons.Filled.Home, contentDescription = "Home")
            }
        }
        if (state.loadingProgress < 100) {
            LinearProgressIndicator(
                progress = { state.loadingProgress / 100f },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val view = state.webView ?: createWebView(ctx, state).also { state.webView = it }
                    (view.parent as? ViewGroup)?.removeView(view)
                    view
                },
            )

            ExtendedFloatingActionButton(
                onClick = { showSheet = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                text = {
                    Text(if (state.found.isEmpty()) "Download" else "${state.found.size} found")
                },
                containerColor = if (state.found.isEmpty())
                    MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer,
            )
        }
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = { showSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                Text(
                    "Download from this page",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Text(
                    "Play the video on the page first. Files it loads will show up here.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Button(
                    onClick = {
                        showSheet = false
                        onSendPageToLinkTab(state.address)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                ) { Text("Find videos on this page (smart mode)") }

                HorizontalDivider()
                if (state.found.isEmpty()) {
                    Text(
                        "No video files spotted yet.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                } else {
                    LazyColumn {
                        items(state.found.reversed(), key = { it.url }) { media ->
                            ListItem(
                                headlineContent = {
                                    Text(media.url.substringAfterLast('/').substringBefore('?').ifBlank { media.url },
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                },
                                supportingContent = { Text(kindLabel(media.kind)) },
                                trailingContent = {
                                    TextButton(onClick = { pending = media }) { Text("Get") }
                                },
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { state.found.clear() },
                        modifier = Modifier.padding(horizontal = 16.dp),
                    ) { Text("Clear list") }
                }
            }
        }
    }

    pending?.let { media ->
        QualityDialog(
            title = media.pageTitle.ifBlank { "Download video" },
            showVideoQualities = media.kind == "m3u8" || media.kind == "mpd",
            onDismiss = { pending = null },
        ) { quality ->
            val cookies = CookieManager.getInstance().getCookie(media.url)
            Downloads.enqueue(
                context,
                DownloadJob(
                    url = media.url,
                    title = media.pageTitle.ifBlank { media.url.substringAfterLast('/').substringBefore('?') },
                    quality = quality,
                    referer = media.pageUrl.ifBlank { null },
                    userAgent = state.webView?.settings?.userAgentString,
                    cookies = cookies,
                ),
            )
            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
            pending = null
            showSheet = false
        }
    }
}

private fun kindLabel(kind: String) = when (kind) {
    "m3u8" -> "Streaming video (HLS)"
    "mpd" -> "Streaming video (DASH)"
    "mp3", "m4a" -> "Audio file"
    "file" -> "File offered by the site"
    else -> "Video file (.$kind)"
}
