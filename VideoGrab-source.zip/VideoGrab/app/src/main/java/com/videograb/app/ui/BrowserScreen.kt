package com.videograb.app.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** A media file spotted while a page loaded. [sizeBytes] fills in once the size check finishes. */
data class FoundMedia(
    val url: String,
    val kind: String,
    val pageUrl: String,
    val pageTitle: String,
    val sizeBytes: Long? = null,
)

private const val HOME_PAGE = "https://www.google.com"

// File types that are whole videos or playlists. Small stream pieces (.ts, .m4s) are skipped on purpose.
private val MEDIA_REGEX = Regex("""\.(mp4|m4v|webm|mov|mkv|m3u8|mpd|mp3|m4a)(\?|#|$)""", RegexOption.IGNORE_CASE)

private val sizeChecker = Executors.newFixedThreadPool(3)
private val mainThread = Handler(Looper.getMainLooper())

/** Holds the WebView and what it found, so they survive switching tabs. */
class BrowserState {
    var webView: WebView? = null
    var address by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var loadingProgress by mutableStateOf(100)
    var canGoBack by mutableStateOf(false)
    val found = mutableStateListOf<FoundMedia>()
    var selected by mutableStateOf<Set<String>>(emptySet())

    fun load(input: String) {
        val text = input.trim()
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains('.') && !text.contains(' ') -> "https://$text"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(text, "UTF-8")
        }
        webView?.loadUrl(url)
    }

    /** Adds a file to the list (once) and starts checking its size. Call on the main thread. */
    fun add(media: FoundMedia, userAgent: String?) {
        if (found.any { it.url == media.url }) return
        found.add(media)
        if (media.sizeBytes == null && media.kind != "m3u8" && media.kind != "mpd") {
            sizeChecker.execute {
                val size = runCatching { probeSize(media.url, media.pageUrl, userAgent) }.getOrNull()
                if (size != null && size > 0) mainThread.post {
                    val i = found.indexOfFirst { it.url == media.url }
                    if (i >= 0) found[i] = found[i].copy(sizeBytes = size)
                }
            }
        }
    }

    fun clear() {
        found.clear()
        selected = emptySet()
    }
}

/**
 * Asks the website how big a file is without downloading it:
 * first a HEAD request, then a 1-byte request whose reply states the full size.
 */
private fun probeSize(url: String, referer: String, userAgent: String?): Long? {
    fun open(method: String, oneByte: Boolean) = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        instanceFollowRedirects = true
        connectTimeout = 8000
        readTimeout = 8000
        userAgent?.let { setRequestProperty("User-Agent", it) }
        if (referer.isNotBlank()) setRequestProperty("Referer", referer)
        CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
        if (oneByte) setRequestProperty("Range", "bytes=0-0")
    }

    val head = open("HEAD", oneByte = false)
    try {
        if (head.responseCode in 200..299 && head.contentLengthLong > 0) return head.contentLengthLong
    } finally {
        head.disconnect()
    }

    val get = open("GET", oneByte = true)
    try {
        get.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull()?.let { return it }
        if (get.responseCode == 200 && get.contentLengthLong > 0) return get.contentLengthLong
    } finally {
        get.disconnect()
    }
    return null
}

@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(context: android.content.Context, state: BrowserState): WebView =
    WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                state.address = url
                state.clear()
            }

            override fun onPageFinished(view: WebView, url: String) {
                state.pageTitle = view.title.orEmpty()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                state.address = url
                state.canGoBack = view.canGoBack()
            }

            // Every network request the page makes passes through here; we note the ones that are media.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()
                val match = MEDIA_REGEX.find(url)
                if (match != null) {
                    val kind = match.groupValues[1].lowercase()
                    view.post {
                        state.add(
                            FoundMedia(url, kind, view.url.orEmpty(), view.title.orEmpty()),
                            view.settings.userAgentString,
                        )
                    }
                }
                return null
            }
        }

        webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                state.loadingProgress = newProgress
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                state.pageTitle = title.orEmpty()
            }
        }

        // When a site offers a file download link, catch it too (the site tells us the size here).
        setDownloadListener { url, _, _, _, contentLength ->
            post {
                state.add(
                    FoundMedia(url, "file", this.url.orEmpty(), this.title.orEmpty(),
                        sizeBytes = contentLength.takeIf { it > 0 }),
                    settings.userAgentString,
                )
            }
        }

        loadUrl(HOME_PAGE)
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(state: BrowserState, onSendPageToLinkTab: (String) -> Unit) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    var showSheet by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<FoundMedia>>(emptyList()) }

    BackHandler(enabled = state.canGoBack) { state.webView?.goBack() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { state.webView?.goBack() }, enabled = state.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            OutlinedTextField(
                value = state.address,
                onValueChange = { state.address = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search or type a web address") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    state.load(state.address)
                    focus.clearFocus()
                }),
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            IconButton(onClick = { state.webView?.reload() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload")
            }
            IconButton(onClick = { state.webView?.loadUrl(HOME_PAGE) }) {
                Icon(Icons.Filled.Home, contentDescription = "Home")
            }
        }
        if (state.loadingProgress < 100) {
            LinearProgressIndicator(
                progress = { state.loadingProgress / 100f },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    val view = state.webView ?: createWebView(ctx, state).also { state.webView = it }
                    (view.parent as? ViewGroup)?.removeView(view)
                    view
                },
            )

            ExtendedFloatingActionButton(
                onClick = { showSheet = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                text = { Text(if (state.found.isEmpty()) "Download" else "${state.found.size} found") },
                containerColor = if (state.found.isEmpty())
                    MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer,
            )
        }
    }

    if (showSheet) {
        ModalBottomSheet(onDismissRequest = { showSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                Text(
                    "Download from this page",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Text(
                    "Play the videos on the page first. Each file it loads shows up here, grouped by size. " +
                        "Small files are often ads or previews.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Button(
                    onClick = {
                        showSheet = false
                        onSendPageToLinkTab(state.address)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                ) { Text("Find videos on this page (smart mode)") }

                HorizontalDivider()
                if (state.found.isEmpty()) {
                    Text(
                        "No video files spotted yet.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                } else {
                    Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { state.selected = state.found.map { it.url }.toSet() }) { Text("Select all") }
                        TextButton(onClick = { state.selected = emptySet() }) { Text("Clear selection") }
                        TextButton(onClick = { state.clear() }) { Text("Clear list") }
                    }
                    GroupedPickList(
                        items = state.found.map { m ->
                            PickItem(
                                key = m.url,
                                title = m.url.substringAfterLast('/').substringBefore('?').ifBlank { m.url },
                                detail = kindLabel(m.kind) + " · " + (runCatching { URL(m.url).host }.getOrNull() ?: ""),
                                sizeBytes = m.sizeBytes,
                            )
                        },
                        selected = state.selected,
                        onSelectionChange = { state.selected = it },
                        modifier = Modifier.heightIn(max = 420.dp),
                    )
                    val chosen = state.found.filter { it.url in state.selected }
                    val chosenBytes = chosen.sumOf { it.sizeBytes ?: 0L }
                    Button(
                        enabled = chosen.isNotEmpty(),
                        onClick = { pending = chosen },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    ) {
                        val size = if (chosenBytes > 0) " · ${formatSize(chosenBytes)}" else ""
                        Text(if (chosen.isEmpty()) "Tick the files you want" else "Download ${chosen.size}$size")
                    }
                    OutlinedButton(
                        onClick = { showSheet = false },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    ) { Text("Close") }
                }
            }
        }
    }

    if (pending.isNotEmpty()) {
        val list = pending
        val anyStream = list.any { it.kind == "m3u8" || it.kind == "mpd" }
        val total = list.sumOf { it.sizeBytes ?: 0L }
        QualityDialog(
            title = if (list.size == 1) list.first().pageTitle.ifBlank { "Download video" } else "Download ${list.size} files",
            subtitle = if (total > 0) formatSize(total) else null,
            showVideoQualities = anyStream,
            onDismiss = { pending = emptyList() },
        ) { quality ->
            val cookieManager = CookieManager.getInstance()
            list.forEachIndexed { i, media ->
                val name = media.url.substringAfterLast('/').substringBefore('?')
                val baseTitle = media.pageTitle.ifBlank { name }
                Downloads.enqueue(
                    context,
                    DownloadJob(
                        url = media.url,
                        title = if (list.size > 1) "$baseTitle (${i + 1})" else baseTitle,
                        quality = quality,
                        referer = media.pageUrl.ifBlank { null },
                        userAgent = state.webView?.settings?.userAgentString,
                        cookies = cookieManager.getCookie(media.url),
                    ),
                )
            }
            Toast.makeText(context, "${list.size} download(s) started", Toast.LENGTH_SHORT).show()
            pending = emptyList()
            state.selected = emptySet()
            showSheet = false
        }
    }
}

private fun kindLabel(kind: String) = when (kind) {
    "m3u8" -> "Stream (HLS)"
    "mpd" -> "Stream (DASH)"
    "mp3", "m4a" -> "Audio"
    "file" -> "File offered by the site"
    else -> "Video .$kind"
}
