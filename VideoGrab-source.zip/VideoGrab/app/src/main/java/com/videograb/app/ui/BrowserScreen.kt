package com.videograb.app.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import android.net.Uri
import android.text.format.DateUtils
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Switch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videograb.app.AdBlocker
import com.videograb.app.AppSettings
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** A media file spotted while a page loaded. Size and preview frame fill in once checked. */
data class FoundMedia(
    val url: String,
    val kind: String,
    val pageUrl: String,
    val pageTitle: String,
    val sizeBytes: Long? = null,
    val frame: Bitmap? = null,
)

private const val HOME_PAGE = "https://www.google.com"

// File types that are whole videos or playlists. Small stream pieces (.ts, .m4s) are skipped on purpose.
private val MEDIA_REGEX = Regex("""\.(mp4|m4v|webm|mov|mkv|m3u8|mpd|mp3|m4a)(\?|#|$)""", RegexOption.IGNORE_CASE)
private val VIDEO_KINDS = setOf("mp4", "m4v", "webm", "mov", "mkv", "file")

private val checker = Executors.newFixedThreadPool(3)
private val mainThread = Handler(Looper.getMainLooper())

// Finds the page's cover picture: a <video poster>, or the image sites show when a link is shared.
private const val PAGE_IMAGE_JS = """(function(){
  var v=document.querySelector('video[poster]'); if(v&&v.poster) return v.poster;
  var m=document.querySelector('meta[property="og:image"],meta[name="twitter:image"]');
  return m?m.content:'';})()"""

/** One browser tab: its own page, history, and list of videos found on it. */
class BrowserTab(val id: Long, val openedFrom: Long?) {
    var webView: WebView? = null
    var address by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var loadingProgress by mutableStateOf(100)
    var canGoBack by mutableStateOf(false)
    var pageImage by mutableStateOf<String?>(null)
    val found = mutableStateListOf<FoundMedia>()

    /** The current page's website, readable from the background thread that checks requests. */
    @Volatile var pageHost: String? = null

    /** How many ad/tracker requests were blocked on the current page. */
    var blockedCount by mutableStateOf(0)
    var selected by mutableStateOf<Set<String>>(emptySet())

    /** Adds a file to the list (once), then checks its size and grabs a preview frame. Main thread only. */
    fun add(media: FoundMedia, userAgent: String?) {
        if (found.any { it.url == media.url }) return
        found.add(media)
        if (media.kind == "m3u8" || media.kind == "mpd") return // streams: no single file to measure
        checker.execute {
            val size = media.sizeBytes ?: runCatching { probeSize(media.url, media.pageUrl, userAgent) }.getOrNull()
            if (size != null && size > 0) update(media.url) { it.copy(sizeBytes = size) }
            if (media.kind in VIDEO_KINDS) {
                grabVideoFrame(media.url, media.pageUrl, userAgent)?.let { frame -> update(media.url) { it.copy(frame = frame) } }
            }
        }
    }

    private fun update(url: String, change: (FoundMedia) -> FoundMedia) {
        mainThread.post {
            val i = found.indexOfFirst { it.url == url }
            if (i >= 0) found[i] = change(found[i])
        }
    }

    fun clearFound() {
        found.clear()
        selected = emptySet()
    }
}

/** All open tabs. Created once per app session so pages stay loaded when you switch screens. */
class BrowserState(private val context: Context) {
    val tabs = mutableStateListOf<BrowserTab>()
    var currentId by mutableStateOf(-1L)

    /** A tab that a pop-up just opened in the background; shows the "Switch" notice. */
    var popupTabId by mutableStateOf<Long?>(null)

    private var nextId = 1L

    val current: BrowserTab?
        get() = tabs.firstOrNull { it.id == currentId } ?: tabs.firstOrNull()

    init {
        newTab(HOME_PAGE, switchTo = true)
    }

    fun newTab(url: String?, switchTo: Boolean, openedFrom: Long? = null): BrowserTab {
        val tab = BrowserTab(nextId++, openedFrom)
        tab.webView = createWebView(context, tab, this)
        tabs.add(tab)
        url?.let { tab.webView?.loadUrl(it) }
        if (switchTo) currentId = tab.id
        return tab
    }

    fun switchTo(tab: BrowserTab) {
        currentId = tab.id
        if (popupTabId == tab.id) popupTabId = null
    }

    fun closeTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        tabs.remove(tab)
        if (popupTabId == tab.id) popupTabId = null
        tab.webView?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        tab.webView = null
        if (tabs.isEmpty()) {
            newTab(HOME_PAGE, switchTo = true)
        } else if (currentId == tab.id) {
            // Go back to the tab that opened it, or the neighbour.
            currentId = tab.openedFrom?.takeIf { id -> tabs.any { it.id == id } }
                ?: tabs[(index - 1).coerceIn(0, tabs.size - 1)].id
        }
    }

    fun load(input: String) {
        val text = input.trim()
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains('.') && !text.contains(' ') -> "https://$text"
            else -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(text, "UTF-8")
        }
        current?.webView?.loadUrl(url)
    }
}

/**
 * Asks the website how big a file is without downloading it:
 * first a HEAD request, then a 1-byte request whose reply states the full size.
 */
private fun probeSize(url: String, referer: String, userAgent: String?): Long? {
    fun open(method: String, oneByte: Boolean) = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        instanceFollowRedirects = true
        connectTimeout = 8000
        readTimeout = 8000
        userAgent?.let { setRequestProperty("User-Agent", it) }
        if (referer.isNotBlank()) setRequestProperty("Referer", referer)
        CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
        if (oneByte) setRequestProperty("Range", "bytes=0-0")
    }

    val head = open("HEAD", oneByte = false)
    try {
        if (head.responseCode in 200..299 && head.contentLengthLong > 0) return head.contentLengthLong
    } finally {
        head.disconnect()
    }

    val get = open("GET", oneByte = true)
    try {
        get.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull()?.let { return it }
        if (get.responseCode == 200 && get.contentLengthLong > 0) return get.contentLengthLong
    } finally {
        get.disconnect()
    }
    return null
}

private fun blockingOn(tab: BrowserTab) =
    AppSettings.adBlock.value && !AdBlocker.isSiteAllowed(tab.pageHost)

@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(context: Context, tab: BrowserTab, browser: BrowserState): WebView =
    WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        // Pop-ups and "open in new window" links become new tabs (see onCreateWindow below).
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                tab.address = url
                tab.pageHost = runCatching { Uri.parse(url).host }.getOrNull()
                tab.pageImage = null
                tab.blockedCount = 0
                tab.clearFound()
            }

            override fun onPageCommitVisible(view: WebView, url: String) {
                if (blockingOn(tab)) view.evaluateJavascript(AdBlocker.HIDE_ADS_JS, null)
            }

            override fun onPageFinished(view: WebView, url: String) {
                tab.pageTitle = view.title.orEmpty()
                if (blockingOn(tab)) view.evaluateJavascript(AdBlocker.HIDE_ADS_JS, null)
                view.evaluateJavascript(PAGE_IMAGE_JS) { result ->
                    val image = runCatching { JSONArray("[$result]").optString(0) }.getOrNull()
                    if (!image.isNullOrBlank() && image.startsWith("http")) tab.pageImage = image
                }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                tab.address = url
                tab.canGoBack = view.canGoBack()
            }

            // Every network request the page makes passes through here; we note the ones that are media.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url.toString()

                // Ad blocker: answer requests to ad/tracker servers with nothing.
                // The page you opened yourself (the main frame) is never blocked.
                val host = request.url.host
                if (!request.isForMainFrame && host != null && blockingOn(tab) && AdBlocker.isAd(host)) {
                    view.post { tab.blockedCount++ }
                    return AdBlocker.emptyResponse()
                }

                val match = MEDIA_REGEX.find(url)
                if (match != null) {
                    val kind = match.groupValues[1].lowercase()
                    view.post {
                        tab.add(FoundMedia(url, kind, view.url.orEmpty(), view.title.orEmpty()), view.settings.userAgentString)
                    }
                }
                return null
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                tab.loadingProgress = newProgress
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                tab.pageTitle = title.orEmpty()
            }

            // A page wants a new window. If you tapped something, open it in a background tab and
            // stay where you are. Pop-ups that open by themselves (usually ads) are blocked.
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false
                val popup = browser.newTab(url = null, switchTo = false, openedFrom = tab.id)
                val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
                transport.webView = popup.webView
                resultMsg.sendToTarget()
                browser.popupTabId = popup.id
                return true
            }

            // A pop-up closed itself.
            override fun onCloseWindow(window: WebView) {
                browser.tabs.firstOrNull { it.webView === window }?.let { browser.closeTab(it) }
            }
        }

        // When a site offers a file download link, catch it too (the site tells us the size here).
        setDownloadListener { url, _, _, _, contentLength ->
            post {
                tab.add(
                    FoundMedia(url, "file", this.url.orEmpty(), this.title.orEmpty(), sizeBytes = contentLength.takeIf { it > 0 }),
                    settings.userAgentString,
                )
            }
        }
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(state: BrowserState, onSendPageToLinkTab: (String) -> Unit) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    var showDownloads by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var showAdBlock by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<FoundMedia>>(emptyList()) }

    val tab = state.current ?: return

    // Back: go back in this tab; if there's no history and it was a pop-up, close it and return.
    BackHandler(enabled = tab.canGoBack || tab.openedFrom != null) {
        if (tab.canGoBack) tab.webView?.goBack() else state.closeTab(tab)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { tab.webView?.goBack() }, enabled = tab.canGoBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            OutlinedTextField(
                value = tab.address,
                onValueChange = { tab.address = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Search or type a web address") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    state.load(tab.address)
                    focus.clearFocus()
                }),
                textStyle = MaterialTheme.typography.bodyMedium,
            )
            IconButton(onClick = { tab.webView?.reload() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Reload")
            }
            // Ad blocker shield, with how many ads it stopped on this page.
            val adBlockOn = AppSettings.adBlock.collectAsStateWithLifecycle().value
            val allowedSites = AdBlocker.allowedSites.collectAsStateWithLifecycle().value
            val siteHost = tab.pageHost?.lowercase()?.removePrefix("www.")
            val activeHere = adBlockOn &&
                (siteHost == null || allowedSites.none { siteHost == it || siteHost.endsWith(".$it") })
            IconButton(onClick = { showAdBlock = true }) {
                BadgedBox(badge = {
                    if (activeHere && tab.blockedCount > 0) {
                        Badge { Text(if (tab.blockedCount > 99) "99+" else tab.blockedCount.toString()) }
                    }
                }) {
                    Icon(
                        if (activeHere) Icons.Filled.Shield else Icons.Outlined.Shield,
                        contentDescription = "Ad blocker",
                        tint = if (activeHere) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            // Tab counter, like in Chrome.
            Surface(
                onClick = { showTabs = true },
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.padding(horizontal = 8.dp).size(28.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        if (state.tabs.size > 99) "99+" else state.tabs.size.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
        if (tab.loadingProgress < 100) {
            LinearProgressIndicator(progress = { tab.loadingProgress / 100f }, modifier = Modifier.fillMaxWidth())
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            // Show the current tab's page. key() makes a fresh holder when the tab changes.
            key(tab.id) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        val view = tab.webView!!
                        (view.parent as? ViewGroup)?.removeView(view)
                        view
                    },
                )
            }

            // "Pop-up opened in a new tab" notice.
            state.popupTabId?.let { popupId ->
                LaunchedEffect(popupId) {
                    delay(6000)
                    if (state.popupTabId == popupId) state.popupTabId = null
                }
                Surface(
                    color = MaterialTheme.colorScheme.inverseSurface,
                    contentColor = MaterialTheme.colorScheme.inverseOnSurface,
                    shape = RoundedCornerShape(12.dp),
                    shadowElevation = 6.dp,
                    modifier = Modifier.align(Alignment.TopCenter).padding(12.dp),
                ) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Opened in a new tab", style = MaterialTheme.typography.bodyMedium)
                        TextButton(onClick = {
                            state.tabs.firstOrNull { it.id == popupId }?.let { state.switchTo(it) }
                            state.popupTabId = null
                        }) { Text("Switch", color = MaterialTheme.colorScheme.inversePrimary) }
                        TextButton(onClick = {
                            state.tabs.firstOrNull { it.id == popupId }?.let { state.closeTab(it) }
                        }) { Text("Close it", color = MaterialTheme.colorScheme.inversePrimary) }
                    }
                }
            }

            ExtendedFloatingActionButton(
                onClick = { showDownloads = true },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                text = { Text(if (tab.found.isEmpty()) "Download" else "${tab.found.size} found") },
                containerColor = if (tab.found.isEmpty())
                    MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primaryContainer,
            )
        }
    }

    if (showAdBlock) {
        AdBlockDialog(tab = tab, onDismiss = { showAdBlock = false })
    }

    if (showTabs) {
        ModalBottomSheet(onDismissRequest = { showTabs = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Tabs (${state.tabs.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Button(onClick = {
                        state.newTab(HOME_PAGE, switchTo = true)
                        showTabs = false
                    }) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Text("New tab", modifier = Modifier.padding(start = 6.dp))
                    }
                }
                LazyColumn(Modifier.heightIn(max = 480.dp).padding(top = 8.dp)) {
                    items(state.tabs.toList(), key = { it.id }) { t ->
                        val isCurrent = t.id == tab.id
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    state.switchTo(t)
                                    showTabs = false
                                }
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            VideoThumb(url = t.pageImage, width = 64.dp, height = 40.dp)
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text(
                                    t.pageTitle.ifBlank { t.address.ifBlank { "New tab" } },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                val videos = if (t.found.isEmpty()) "" else " · ${t.found.size} found"
                                Text(
                                    (runCatching { URL(t.address).host }.getOrNull() ?: t.address) + videos,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            IconButton(onClick = { state.closeTab(t) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Close tab")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDownloads) {
        ModalBottomSheet(onDismissRequest = { showDownloads = false }) {
            Column(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
                Text(
                    "Download from this page",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Text(
                    "Play the videos on the page first. Each file it loads shows up here, grouped by size. " +
                        "Small files are often ads or previews.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Button(
                    onClick = {
                        showDownloads = false
                        onSendPageToLinkTab(tab.address)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                ) { Text("Find videos on this page (smart mode)") }

                HorizontalDivider()
                if (tab.found.isEmpty()) {
                    Text(
                        "No video files spotted yet.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                } else {
                    Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { tab.selected = tab.found.map { it.url }.toSet() }) { Text("Select all") }
                        TextButton(onClick = { tab.selected = emptySet() }) { Text("Clear selection") }
                        TextButton(onClick = { tab.clearFound() }) { Text("Clear list") }
                    }
                    GroupedPickList(
                        items = tab.found.map { m ->
                            PickItem(
                                key = m.url,
                                title = m.url.substringAfterLast('/').substringBefore('?').ifBlank { m.url },
                                detail = kindLabel(m.kind) + " · " + (runCatching { URL(m.url).host }.getOrNull() ?: ""),
                                sizeBytes = m.sizeBytes,
                                thumbBitmap = m.frame,
                                // Streams and files without a frame use the page's cover picture.
                                thumbUrl = if (m.frame == null) tab.pageImage else null,
                            )
                        },
                        selected = tab.selected,
                        onSelectionChange = { tab.selected = it },
                        modifier = Modifier.heightIn(max = 420.dp),
                    )
                    val chosen = tab.found.filter { it.url in tab.selected }
                    val chosenBytes = chosen.sumOf { it.sizeBytes ?: 0L }
                    Button(
                        enabled = chosen.isNotEmpty(),
                        onClick = { pending = chosen },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    ) {
                        val size = if (chosenBytes > 0) " · ${formatSize(chosenBytes)}" else ""
                        Text(if (chosen.isEmpty()) "Tick the files you want" else "Download ${chosen.size}$size")
                    }
                    OutlinedButton(
                        onClick = { showDownloads = false },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    ) { Text("Close") }
                }
            }
        }
    }

    if (pending.isNotEmpty()) {
        val list = pending
        val anyStream = list.any { it.kind == "m3u8" || it.kind == "mpd" }
        val total = list.sumOf { it.sizeBytes ?: 0L }
        QualityDialog(
            title = if (list.size == 1) list.first().pageTitle.ifBlank { "Download video" } else "Download ${list.size} files",
            subtitle = if (total > 0) formatSize(total) else null,
            showVideoQualities = anyStream,
            thumbBitmap = list.first().frame,
            thumbUrl = if (list.first().frame == null) tab.pageImage else null,
            onDismiss = { pending = emptyList() },
        ) { quality ->
            val cookieManager = CookieManager.getInstance()
            list.forEachIndexed { i, media ->
                val name = media.url.substringAfterLast('/').substringBefore('?')
                val baseTitle = media.pageTitle.ifBlank { name }
                Downloads.enqueue(
                    context,
                    DownloadJob(
                        url = media.url,
                        title = if (list.size > 1) "$baseTitle (${i + 1})" else baseTitle,
                        quality = quality,
                        referer = media.pageUrl.ifBlank { null },
                        userAgent = tab.webView?.settings?.userAgentString,
                        cookies = cookieManager.getCookie(media.url),
                        // A direct file's size is exact, so progress and time left are accurate.
                        sizeEstimate = media.sizeBytes.takeIf { !quality.audioOnly },
                        thumbnailUrl = tab.pageImage,
                    ),
                )
            }
            Toast.makeText(context, "${list.size} download(s) started", Toast.LENGTH_SHORT).show()
            pending = emptyList()
            tab.selected = emptySet()
            showDownloads = false
        }
    }
}

private fun kindLabel(kind: String) = when (kind) {
    "m3u8" -> "Stream (HLS)"
    "mpd" -> "Stream (DASH)"
    "mp3", "m4a" -> "Audio"
    "file" -> "File offered by the site"
    else -> "Video .$kind"
}

/** The shield button's window: on/off, allow this site, block list status and update. */
@Composable
private fun AdBlockDialog(tab: BrowserTab, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val on by AppSettings.adBlock.collectAsStateWithLifecycle()
    val allowed by AdBlocker.allowedSites.collectAsStateWithLifecycle()
    val listSize by AdBlocker.listSize.collectAsStateWithLifecycle()
    val lastUpdated by AdBlocker.lastUpdated.collectAsStateWithLifecycle()
    var updating by remember { mutableStateOf(false) }
    val host = tab.pageHost?.removePrefix("www.")
    val siteAllowed = remember(allowed, host) { AdBlocker.isSiteAllowed(host) }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Shield, contentDescription = null) },
        title = { Text("Ad blocker") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Block ads and trackers", style = MaterialTheme.typography.bodyLarge)
                        Text("In the built-in browser", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = on, onCheckedChange = {
                        AppSettings.setAdBlock(context, it)
                        tab.webView?.reload()
                    })
                }
                if (on && host != null) {
                    Text(
                        if (siteAllowed) "Ads are allowed on $host."
                        else "${tab.blockedCount} ads and trackers blocked on this page.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Allow ads on this site", style = MaterialTheme.typography.bodyLarge)
                            Text("Use this if a page or video won't load", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = siteAllowed, onCheckedChange = {
                            AdBlocker.setSiteAllowed(context, host, it)
                            tab.webView?.reload()
                        })
                    }
                }
                HorizontalDivider()
                val updatedText = if (lastUpdated <= 0) "built-in list only"
                else "updated " + DateUtils.getRelativeTimeSpanString(lastUpdated).toString().lowercase()
                Text(
                    "Block list: ${"%,d".format(listSize)} sites · $updatedText",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedButton(
                    enabled = !updating,
                    onClick = {
                        updating = true
                        scope.launch {
                            val msg = try {
                                "Block list updated: ${"%,d".format(AdBlocker.update(context))} sites"
                            } catch (e: Exception) {
                                "Couldn't update the list. Check your internet and try again."
                            }
                            updating = false
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                    },
                ) { Text(if (updating) "Updating…" else "Update block list") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )
}
