package com.videograb.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import android.webkit.CookieManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Keeps recently shown thumbnails in memory so lists scroll smoothly. */
object ThumbCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun get(key: String?): Bitmap? = key?.let { cache.get(it) }
    fun put(key: String, bitmap: Bitmap) { cache.put(key, bitmap) }
}

/** Downloads a picture (e.g. a video's cover image) and shrinks it to about 320 px wide. */
fun loadRemoteImage(url: String, referer: String? = null): Bitmap? {
    ThumbCache.get(url)?.let { return it }
    val conn = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 8000
        readTimeout = 8000
        instanceFollowRedirects = true
        referer?.let { setRequestProperty("Referer", it) }
        CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
    }
    val bytes = try {
        if (conn.responseCode !in 200..299) return null
        conn.inputStream.use { input -> input.readBytes().takeIf { it.size < 8 * 1024 * 1024 } } ?: return null
    } finally {
        conn.disconnect()
    }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= 320) sample *= 2
    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: return null
    ThumbCache.put(url, bitmap)
    return bitmap
}

/**
 * Grabs one frame from an online video file without downloading all of it
 * (the phone's video reader only fetches the bytes it needs).
 */
fun grabVideoFrame(url: String, referer: String?, userAgent: String?): Bitmap? {
    ThumbCache.get("frame:$url")?.let { return it }
    val retriever = MediaMetadataRetriever()
    return try {
        val headers = HashMap<String, String>()
        referer?.takeIf { it.isNotBlank() }?.let { headers["Referer"] = it }
        userAgent?.let { headers["User-Agent"] = it }
        CookieManager.getInstance().getCookie(url)?.let { headers["Cookie"] = it }
        retriever.setDataSource(url, headers)
        val frame = if (Build.VERSION.SDK_INT >= 27) {
            retriever.getScaledFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
        } else {
            retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { Bitmap.createScaledBitmap(it, 320, (320f * it.height / it.width).toInt().coerceAtLeast(1), true) }
        }
        frame?.also { ThumbCache.put("frame:$url", it) }
    } catch (e: Exception) {
        null
    } finally {
        runCatching { retriever.release() }
    }
}

/** Android's own preview of a saved file (Android 10+). */
fun loadFileThumbnail(context: Context, uri: Uri): Bitmap? {
    if (Build.VERSION.SDK_INT < 29) return null
    ThumbCache.get(uri.toString())?.let { return it }
    return runCatching { context.contentResolver.loadThumbnail(uri, Size(320, 180), null) }
        .getOrNull()?.also { ThumbCache.put(uri.toString(), it) }
}

/**
 * A small rounded thumbnail. Shows [bitmap] if given, otherwise loads [url] (a picture link)
 * or [fileUri] (a saved file). Falls back to a film icon.
 */
@Composable
fun VideoThumb(
    bitmap: Bitmap? = null,
    url: String? = null,
    fileUri: String? = null,
    width: Dp = 72.dp,
    height: Dp = 44.dp,
) {
    val context = LocalContext.current
    val loaded by produceState(initialValue = bitmap ?: ThumbCache.get(url) ?: ThumbCache.get(fileUri), bitmap, url, fileUri) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                when {
                    fileUri != null -> loadFileThumbnail(context, Uri.parse(fileUri))
                        ?: url?.let { runCatching { loadRemoteImage(it) }.getOrNull() }
                    url != null -> runCatching { loadRemoteImage(url) }.getOrNull()
                    else -> null
                }
            }
        }
    }
    Box(
        Modifier
            .size(width, height)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val image = loaded
        if (image != null) {
            Image(
                bitmap = image.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(width, height),
            )
        } else {
            Icon(Icons.Filled.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
