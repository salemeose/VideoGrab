package com.videograb.app

import android.content.Context
import android.webkit.WebResourceResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Blocks requests to ad and tracker servers in the built-in browser.
 *
 * Starts with a small built-in list, then downloads a full community list (~80,000 ad, tracker and
 * malware domains) and refreshes it weekly. Sites can be put on an allow list if blocking breaks them.
 */
object AdBlocker {

    private const val LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    private const val LIST_FILE = "adblock_hosts.txt"
    private const val PREFS = "adblock"
    private const val KEY_ALLOWED = "allowed_sites"
    private const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

    /** Well-known ad, pop-up and tracking networks, so blocking works before the full list arrives. */
    private val BUILT_IN = setOf(
        // Google ads and tracking
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagservices.com", "app-measurement.com",
        // Big ad exchanges
        "adnxs.com", "adsrvr.org", "advertising.com", "amazon-adsystem.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com", "indexww.com", "bidswitch.net",
        "adform.net", "smartadserver.com", "yieldmo.com", "sharethrough.com", "teads.tv", "33across.com",
        "lijit.com", "sovrn.com", "media.net", "contextweb.com", "spotxchange.com", "springserve.com",
        "adition.com", "serving-sys.com", "flashtalking.com", "yieldlab.net", "smaato.net", "adcolony.com",
        // "Recommended for you" link farms
        "taboola.com", "outbrain.com", "mgid.com", "revcontent.com", "zergnet.com",
        // Pop-up / pop-under networks common on video sites
        "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "juicyads.com",
        "trafficjunky.net", "hilltopads.net", "onclickads.net", "adcash.com", "clickadu.com", "zedo.com",
        "adblade.com", "trafficfactory.biz", "a-ads.com",
        // Measurement / trackers
        "scorecardresearch.com", "quantserve.com", "moatads.com", "chartbeat.com", "hotjar.com",
        "adsafeprotected.com", "doubleverify.com",
        // In-app ad networks (also used on mobile web)
        "applovin.com", "applvn.com", "inmobi.com", "vungle.com", "chartboost.com", "mintegral.com",
        "unityads.unity3d.com", "ads.mopub.com", "pangleglobal.com",
    )

    @Volatile private var domains: Set<String> = BUILT_IN

    private val _listSize = MutableStateFlow(BUILT_IN.size)
    val listSize: StateFlow<Int> = _listSize

    private val _lastUpdated = MutableStateFlow(0L)
    val lastUpdated: StateFlow<Long> = _lastUpdated

    private val _allowedSites = MutableStateFlow<Set<String>>(emptySet())
    val allowedSites: StateFlow<Set<String>> = _allowedSites

    /** Loads the saved list and allow list; downloads a fresh list if it's missing or a week old. */
    suspend fun init(context: Context) = withContext(Dispatchers.IO) {
        _allowedSites.value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_ALLOWED, emptySet()).orEmpty().toSet()
        val file = File(context.filesDir, LIST_FILE)
        if (file.exists()) {
            runCatching { useList(parse(file.readText()), file.lastModified()) }
        }
        if (!file.exists() || System.currentTimeMillis() - file.lastModified() > WEEK_MS) {
            runCatching { update(context) }
        }
    }

    /** Downloads the newest full list. Returns how many sites it blocks. */
    suspend fun update(context: Context): Int = withContext(Dispatchers.IO) {
        val conn = (URL(LIST_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
        }
        val text = try {
            if (conn.responseCode !in 200..299) throw IllegalStateException("Server said ${conn.responseCode}")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val parsed = parse(text)
        if (parsed.size < 1000) throw IllegalStateException("The downloaded list looks incomplete.")
        val file = File(context.filesDir, LIST_FILE)
        file.writeText(text)
        useList(parsed, file.lastModified())
        domains.size
    }

    private fun useList(parsed: Set<String>, updatedAt: Long) {
        domains = parsed + BUILT_IN
        _listSize.value = domains.size
        _lastUpdated.value = updatedAt
    }

    /** Reads "0.0.0.0 ads.example.com" lines (the standard hosts-file format). */
    private fun parse(text: String): Set<String> {
        val result = HashSet<String>(120_000)
        text.lineSequence().forEach { raw ->
            val line = raw.substringBefore('#').trim()
            if (line.isEmpty()) return@forEach
            val parts = line.split(' ', '\t').filter { it.isNotEmpty() }
            if (parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1")) {
                val host = parts[1].lowercase()
                if (host != "localhost" && host != "0.0.0.0" && host.contains('.')) result.add(host)
            }
        }
        return result
    }

    /** True if [host] or any parent domain (ads.x.com → x.com) is on the list. */
    fun isAd(host: String): Boolean {
        val list = domains
        var h = host.lowercase()
        while (true) {
            if (h in list) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false
        }
    }

    fun isSiteAllowed(pageHost: String?): Boolean {
        if (pageHost.isNullOrBlank()) return false
        val host = pageHost.lowercase().removePrefix("www.")
        return _allowedSites.value.any { host == it || host.endsWith(".$it") }
    }

    /** Turn ad blocking off (or back on) for one website. */
    fun setSiteAllowed(context: Context, pageHost: String, allowed: Boolean) {
        val host = pageHost.lowercase().removePrefix("www.")
        val updated = if (allowed) _allowedSites.value + host else _allowedSites.value - host
        _allowedSites.value = updated
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_ALLOWED, updated).apply()
    }

    /** What the browser gets instead of the ad: nothing. */
    fun emptyResponse() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** Hides ad boxes that are left empty on the page after their content was blocked. */
    const val HIDE_ADS_JS = """(function(){
      if(document.getElementById('vg-adblock'))return;
      var s=document.createElement('style');s.id='vg-adblock';
      s.textContent='ins.adsbygoogle,.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[id^="taboola"],'+
        '.taboola,[id^="outbrain"],.OUTBRAIN,iframe[src*="doubleclick"],iframe[src*="googlesyndication"],'+
        'iframe[src*="amazon-adsystem"],.ad-slot,.ad-banner,.adsbox{display:none!important}';
      (document.head||document.documentElement).appendChild(s);})()"""
}
