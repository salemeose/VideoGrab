package com.videograb.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Switch
import com.videograb.app.bubble.BubbleService
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import com.videograb.app.Engine
import com.videograb.app.AppSettings
import com.videograb.app.LinkEntry
import com.videograb.app.LinkInfo
import com.videograb.app.Quality
import kotlinx.coroutines.launch

/** The size estimate is for best quality, so it's only passed on when best quality is chosen. */
private fun LinkEntry.toJob(quality: Quality) = DownloadJob(
    url = url,
    title = title,
    quality = quality,
    sizeEstimate = sizeBytes.takeIf { quality == Quality.BEST },
    thumbnailUrl = thumbnailUrl,
)

/** On/off switch for Turbo downloads. */
@Composable
private fun TurboCard() {
    val context = LocalContext.current
    val turbo by AppSettings.turbo.collectAsStateWithLifecycle()
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Turbo downloads", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Downloads each file over up to 16 connections at once. Much faster on most sites. " +
                        "Turn it off if a site gives errors.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(checked = turbo, onCheckedChange = { AppSettings.setTurbo(context, it) })
        }
    }
}

private fun formatDuration(seconds: Int): String =
    if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, (seconds % 3600) / 60, seconds % 60)
    else "%d:%02d".format(seconds / 60, seconds % 60)

/** On/off switch for the floating bubble, including the "display over other apps" permission step. */
@Composable
private fun BubbleCard() {
    val context = LocalContext.current
    val running by BubbleService.running.collectAsStateWithLifecycle()

    // Opens Android's permission page; when the user comes back, start the bubble if they allowed it.
    val permissionPage = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (BubbleService.canShow(context)) BubbleService.start(context)
        else Toast.makeText(context, "The bubble needs \"Display over other apps\" to be allowed.", Toast.LENGTH_LONG).show()
    }

    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Floating bubble", style = MaterialTheme.typography.titleSmall)
                Text(
                    "A bubble that stays over other apps. Copy a link anywhere, tap the bubble, tap Download. " +
                        "It also shows download progress.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(
                checked = running,
                onCheckedChange = { on ->
                    when {
                        !on -> BubbleService.stop(context)
                        BubbleService.canShow(context) -> BubbleService.start(context)
                        else -> {
                            Toast.makeText(context, "Allow VideoGrab, then press back.", Toast.LENGTH_LONG).show()
                            permissionPage.launch(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            )
                        }
                    }
                },
            )
        }
    }
}

/** Paste a link from any app, let yt-dlp work out the video, pick a quality, download. */
@Composable
fun LinkScreen(incomingLink: String?, onIncomingHandled: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engineState by Engine.state.collectAsStateWithLifecycle()

    var link by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var found by remember { mutableStateOf<LinkInfo?>(null) }
    var updating by remember { mutableStateOf(false) }

    fun lookUp(url: String) {
        if (url.isBlank()) return
        busy = true
        error = null
        scope.launch {
            try {
                found = Engine.lookUp(context, url.trim())
            } catch (e: Exception) {
                error = "Couldn't find a video at this link. " +
                    "Check the link, try updating the engine below, or open the page in the Browser tab."
            } finally {
                busy = false
            }
        }
    }

    // A link shared from another app, or sent from the Browser tab, is looked up straight away.
    LaunchedEffect(incomingLink) {
        if (!incomingLink.isNullOrBlank()) {
            link = incomingLink
            onIncomingHandled()
            lookUp(incomingLink)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Download from a link", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Copy a video's link in any app (or use Share → VideoGrab), then paste it here.",
            style = MaterialTheme.typography.bodyMedium,
        )

        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Video link") },
            singleLine = true,
            trailingIcon = {
                IconButton(onClick = {
                    val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clip.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()?.let { link = it }
                }) { Icon(Icons.Filled.ContentPaste, contentDescription = "Paste") }
            },
        )

        Button(
            onClick = { lookUp(link) },
            enabled = !busy && link.isNotBlank() && engineState != Engine.State.FAILED,
            modifier = Modifier.fillMaxWidth(),
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.size(8.dp))
                Text("Looking…")
            } else {
                Text("Find video")
            }
        }

        when (engineState) {
            Engine.State.PREPARING -> Text("Setting up the download engine (first launch only)…",
                style = MaterialTheme.typography.bodySmall)
            Engine.State.FAILED -> Text("The download engine couldn't start on this phone.",
                color = MaterialTheme.colorScheme.error)
            Engine.State.READY -> {}
        }

        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        Spacer(Modifier.height(8.dp))
        BubbleCard()
        TurboCard()

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Engine updates", style = MaterialTheme.typography.titleSmall)
                Text(
                    "Websites change often. If links stop working, update the engine (needs internet, takes a few seconds).",
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        enabled = !updating,
                        onClick = {
                            updating = true
                            scope.launch {
                                val msg = try { Engine.update(context) } catch (e: Exception) {
                                    "Update failed: ${e.message?.take(120)}"
                                }
                                updating = false
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        },
                    ) { Text(if (updating) "Updating…" else "Update engine") }
                }
            }
        }

        Text(
            "Only download videos you own or have permission to save.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    found?.let { info ->
        if (info.entries.size == 1) {
            val entry = info.entries.first()
            QualityDialog(
                title = entry.title,
                subtitle = entry.sizeBytes?.let { "About ${formatSize(it)} at best quality" },
                thumbUrl = entry.thumbnailUrl,
                onDismiss = { found = null },
            ) { quality ->
                Downloads.enqueue(context, entry.toJob(quality))
                Toast.makeText(context, "Download started — see the Downloads tab", Toast.LENGTH_SHORT).show()
                found = null
            }
        } else {
            // Several videos behind one link: let the user pick, grouped by size.
            val items = info.entries.mapIndexed { i, e ->
                PickItem(
                    key = "$i|${e.url}",
                    title = e.title,
                    detail = e.durationSec?.let { formatDuration(it) } ?: e.url,
                    sizeBytes = e.sizeBytes,
                    thumbUrl = e.thumbnailUrl,
                )
            }
            PickVideosDialog(
                title = info.title,
                items = items,
                onDismiss = { found = null },
            ) { keys, quality ->
                val chosen = info.entries.filterIndexed { i, e -> "$i|${e.url}" in keys }
                chosen.forEach { e -> Downloads.enqueue(context, e.toJob(quality)) }
                Toast.makeText(context, "${chosen.size} downloads started", Toast.LENGTH_SHORT).show()
                found = null
            }
        }
    }
}
