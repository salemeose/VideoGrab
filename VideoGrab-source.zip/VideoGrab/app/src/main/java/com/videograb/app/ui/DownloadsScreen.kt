package com.videograb.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import com.videograb.app.Quality

@Composable
fun DownloadsScreen() {
    val context = LocalContext.current
    val flow = remember { WorkManager.getInstance(context).getWorkInfosByTagFlow(Downloads.TAG) }
    val jobs by flow.collectAsStateWithLifecycle(initialValue = emptyList())

    // Running and waiting jobs first, then finished ones.
    val sorted = jobs.sortedBy { if (it.state.isFinished) 1 else 0 }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Downloads", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = { Downloads.clearFinished(context) }) { Text("Clear finished") }
        }
        Text(
            "Files are saved in your phone's Downloads/VideoGrab folder.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        if (sorted.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No downloads yet.", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(sorted, key = { it.id }) { info -> DownloadCard(info) }
            }
        }
    }
}

@Composable
private fun DownloadCard(info: WorkInfo) {
    val context = LocalContext.current
    val title = Downloads.titleOf(info)
    val url = info.tags.firstOrNull { it.startsWith(Downloads.URL_TAG_PREFIX) }
        ?.removePrefix(Downloads.URL_TAG_PREFIX)
    val quality = info.tags.firstOrNull { it.startsWith(Downloads.QUALITY_TAG_PREFIX) }
        ?.removePrefix(Downloads.QUALITY_TAG_PREFIX)
        ?.let { runCatching { Quality.valueOf(it) }.getOrNull() } ?: Quality.BEST

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)

            when (info.state) {
                WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> {
                    Text("Waiting…", style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                WorkInfo.State.RUNNING -> {
                    val percent = info.progress.getInt(Downloads.KEY_PROGRESS, -1)
                    val detail = info.progress.getString(Downloads.KEY_DETAIL) ?: "Starting…"
                    Text(detail, style = MaterialTheme.typography.bodySmall)
                    if (percent >= 0) {
                        LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                    } else {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
                WorkInfo.State.SUCCEEDED -> Text(
                    "Done · " + formatSize(info.outputData.getLong(Downloads.KEY_SIZE, 0L)).replace("Size unknown", "") +
                        " · " + (info.outputData.getString(Downloads.KEY_FILE_NAME) ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                WorkInfo.State.FAILED -> Text(
                    info.outputData.getString(Downloads.KEY_ERROR) ?: "Failed",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
                WorkInfo.State.CANCELLED -> Text("Cancelled", style = MaterialTheme.typography.bodySmall)
            }

            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                if (!info.state.isFinished) {
                    TextButton(onClick = { Downloads.cancel(context, info.id) }) { Text("Cancel") }
                }
                if (info.state == WorkInfo.State.SUCCEEDED) {
                    val uri = info.outputData.getString(Downloads.KEY_FILE_URI)
                    if (uri != null) {
                        TextButton(onClick = { openFile(context, Uri.parse(uri)) }) { Text("Open") }
                    }
                }
                if ((info.state == WorkInfo.State.FAILED || info.state == WorkInfo.State.CANCELLED) && url != null) {
                    TextButton(onClick = {
                        // Retries without the browser's referer/cookies, which usually works for links.
                        Downloads.enqueue(context, DownloadJob(url = url, title = title, quality = quality))
                    }) { Text("Retry") }
                }
            }
        }
    }
}

private fun openFile(context: android.content.Context, uri: Uri) {
    val type = context.contentResolver.getType(uri) ?: "video/*"
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, type)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No app on this phone can open this file.", Toast.LENGTH_SHORT).show()
    }
}
