package com.videograb.app

import android.content.Context
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Quality choices shown to the user, mapped to yt-dlp format rules. */
enum class Quality(val label: String, val format: String?, val audioOnly: Boolean = false) {
    BEST("Best available", "bv*+ba/b"),
    P1080("Up to 1080p", "bv*[height<=1080]+ba/b[height<=1080]/b"),
    P720("Up to 720p", "bv*[height<=720]+ba/b[height<=720]/b"),
    P480("Up to 480p", "bv*[height<=480]+ba/b[height<=480]/b"),
    AUDIO("Audio only (MP3)", null, audioOnly = true),
}

/** One video found behind a link. [sizeBytes] is an estimate at best quality, or null if the site doesn't say. */
data class LinkEntry(
    val url: String,
    val title: String,
    val sizeBytes: Long?,
    val durationSec: Int?,
    val thumbnailUrl: String? = null,
)

/** Everything found behind a link: usually one video, sometimes several. */
data class LinkInfo(val title: String, val entries: List<LinkEntry>)

/** Wraps the yt-dlp engine: setup, looking up a link, and self-updating. */
object Engine {

    enum class State { PREPARING, READY, FAILED }

    private val _state = MutableStateFlow(State.PREPARING)
    val state: StateFlow<State> = _state

    @Volatile private var initialized = false

    /** True when the multi-connection downloader (aria2c) started; used by Turbo mode. */
    @Volatile var turboAvailable = false
        private set
    private val lock = Any()

    /** Safe to call from any background thread, any number of times. */
    fun ensureReady(context: Context) {
        if (initialized) return
        synchronized(lock) {
            if (initialized) return
            try {
                YoutubeDL.getInstance().init(context.applicationContext)
                FFmpeg.getInstance().init(context.applicationContext)
                // Optional: if aria2c can't start on this phone, downloads still work, just without Turbo.
                turboAvailable = runCatching { Aria2c.getInstance().init(context.applicationContext) }.isSuccess
                initialized = true
                _state.value = State.READY
            } catch (e: Exception) {
                _state.value = State.FAILED
                throw e
            }
        }
    }

    /**
     * Asks yt-dlp what is behind a link: one video, or several (a playlist, a page with many videos).
     * Returns each video's own link, title and estimated size at best quality. Capped at 30 videos.
     */
    suspend fun lookUp(context: Context, url: String): LinkInfo = withContext(Dispatchers.IO) {
        ensureReady(context)
        val request = YoutubeDLRequest(url).apply {
            addOption("-J")
            addOption("--no-playlist")
            addOption("--playlist-end", "30")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(request).out
        val start = out.indexOf('{')
        if (start < 0) throw IllegalStateException("No video information found.")
        val json = JSONObject(out.substring(start))

        if (json.optString("_type") == "playlist") {
            val list = json.optJSONArray("entries") ?: JSONArray()
            val entries = (0 until list.length()).mapNotNull { i -> list.optJSONObject(i)?.let { toEntry(it, url) } }
            if (entries.isEmpty()) throw IllegalStateException("The page has no downloadable videos.")
            LinkInfo(json.optString("title").ifBlank { url }, entries)
        } else {
            val entry = toEntry(json, url)
            LinkInfo(entry.title, listOf(entry))
        }
    }

    private fun toEntry(o: JSONObject, fallbackUrl: String): LinkEntry {
        val link = o.optString("webpage_url")
            .ifBlank { o.optString("original_url") }
            .ifBlank { o.optString("url") }
            .ifBlank { fallbackUrl }
        val size = listOf("filesize", "filesize_approx").map { o.optLong(it, 0L) }.firstOrNull { it > 0 }
            ?: sizeOfRequestedFormats(o)
        val duration = o.optDouble("duration", Double.NaN).takeIf { !it.isNaN() }?.toInt()
        val thumb = o.optString("thumbnail").ifBlank {
            // Some sites only give a list of thumbnails; take the last (usually the largest).
            o.optJSONArray("thumbnails")?.let { arr ->
                if (arr.length() > 0) arr.optJSONObject(arr.length() - 1)?.optString("url").orEmpty() else ""
            }.orEmpty()
        }.ifBlank { null }
        return LinkEntry(link, o.optString("title").ifBlank { link }, size, duration, thumb)
    }

    /** When video and sound are separate files, the size is the two added together. */
    private fun sizeOfRequestedFormats(o: JSONObject): Long? {
        val formats = o.optJSONArray("requested_formats") ?: return null
        var total = 0L
        for (i in 0 until formats.length()) {
            val f = formats.optJSONObject(i) ?: continue
            total += f.optLong("filesize", 0L).takeIf { it > 0 } ?: f.optLong("filesize_approx", 0L)
        }
        return total.takeIf { it > 0 }
    }

    /** Asks yt-dlp what is behind a link. Returns the video title. */
    suspend fun lookUpTitle(context: Context, url: String): String = withContext(Dispatchers.IO) {
        ensureReady(context)
        val request = YoutubeDLRequest(url)
        request.addOption("--no-playlist")
        val info = YoutubeDL.getInstance().getInfo(request)
        info.title ?: url
    }

    /** Downloads the newest yt-dlp so sites that changed keep working. Returns a short status. */
    suspend fun update(context: Context): String = withContext(Dispatchers.IO) {
        ensureReady(context)
        val status = YoutubeDL.getInstance()
            .updateYoutubeDL(context.applicationContext, YoutubeDL.UpdateChannel._STABLE)
        when (status) {
            YoutubeDL.UpdateStatus.DONE -> "Engine updated to the latest version."
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "Engine is already up to date."
            else -> "Update finished."
        }
    }
}
