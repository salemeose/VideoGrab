package com.videograb.app

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

/** Quality choices shown to the user, mapped to yt-dlp format rules. */
enum class Quality(val label: String, val format: String?, val audioOnly: Boolean = false) {
    BEST("Best available", "bv*+ba/b"),
    P1080("Up to 1080p", "bv*[height<=1080]+ba/b[height<=1080]/b"),
    P720("Up to 720p", "bv*[height<=720]+ba/b[height<=720]/b"),
    P480("Up to 480p", "bv*[height<=480]+ba/b[height<=480]/b"),
    AUDIO("Audio only (MP3)", null, audioOnly = true),
}

/** Wraps the yt-dlp engine: setup, looking up a link, and self-updating. */
object Engine {

    enum class State { PREPARING, READY, FAILED }

    private val _state = MutableStateFlow(State.PREPARING)
    val state: StateFlow<State> = _state

    @Volatile private var initialized = false
    private val lock = Any()

    /** Safe to call from any background thread, any number of times. */
    fun ensureReady(context: Context) {
        if (initialized) return
        synchronized(lock) {
            if (initialized) return
            try {
                YoutubeDL.getInstance().init(context.applicationContext)
                FFmpeg.getInstance().init(context.applicationContext)
                initialized = true
                _state.value = State.READY
            } catch (e: Exception) {
                _state.value = State.FAILED
                throw e
            }
        }
    }

    /** Asks yt-dlp what is behind a link. Returns the video title. */
    suspend fun lookUpTitle(context: Context, url: String): String = withContext(Dispatchers.IO) {
        ensureReady(context)
        val request = YoutubeDLRequest(url)
        request.addOption("--no-playlist")
        val info = YoutubeDL.getInstance().getInfo(request)
        info.title ?: url
    }

    /** Downloads the newest yt-dlp so sites that changed keep working. Returns a short status. */
    suspend fun update(context: Context): String = withContext(Dispatchers.IO) {
        ensureReady(context)
        val status = YoutubeDL.getInstance()
            .updateYoutubeDL(context.applicationContext, YoutubeDL.UpdateChannel._STABLE)
        when (status) {
            YoutubeDL.UpdateStatus.DONE -> "Engine updated to the latest version."
            YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "Engine is already up to date."
            else -> "Update finished."
        }
    }
}
