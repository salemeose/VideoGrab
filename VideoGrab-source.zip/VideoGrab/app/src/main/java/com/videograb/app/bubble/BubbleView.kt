package com.videograb.app.bubble

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/**
 * The floating bubble: a black disc with a red download arrow.
 * While downloads run, a red ring fills up around it, and a badge shows how many are active.
 */
@SuppressLint("ViewConstructor")
class BubbleView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val sizePx = (60 * density).toInt()
    private val ringWidth = 5 * density

    private val red = Color.parseColor("#E50914")
    private val darkRed = Color.parseColor("#4A0A0D")

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B0B0B") }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ringWidth; color = darkRed
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ringWidth; color = red; strokeCap = Paint.Cap.ROUND
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = red }
    private val checkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4 * density; color = Color.WHITE
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = red }
    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 11 * density; textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val arc = RectF()
    private val iconPath = Path()
    private var spinAngle = 0f

    /** -1 means "working, but the percentage isn't known yet". */
    var percent: Int = -1
        set(value) { field = value; invalidate() }

    var activeCount: Int = 0
        set(value) { field = value; invalidate() }

    private var showDone = false

    init {
        elevation = 8 * density
    }

    /** Shows a white tick for a couple of seconds after a download finishes. */
    fun flashDone() {
        showDone = true
        invalidate()
        postDelayed({ showDone = false; invalidate() }, 2500)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(sizePx, sizePx)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = width / 2f - ringWidth / 2f - density

        canvas.drawCircle(cx, cy, radius, discPaint)
        canvas.drawCircle(cx, cy, radius, trackPaint)

        arc.set(cx - radius, cy - radius, cx + radius, cy + radius)
        if (activeCount > 0) {
            if (percent >= 0) {
                canvas.drawArc(arc, -90f, 360f * percent.coerceIn(0, 100) / 100f, false, progressPaint)
            } else {
                // Unknown percentage: a spinning segment.
                canvas.drawArc(arc, spinAngle, 90f, false, progressPaint)
                spinAngle = (spinAngle + 6f) % 360f
                postInvalidateOnAnimation()
            }
        } else {
            canvas.drawCircle(cx, cy, radius, progressPaint.apply { alpha = 255 })
        }

        if (showDone) drawTick(canvas, cx, cy, radius) else drawArrow(canvas, cx, cy, radius)

        if (activeCount > 1) {
            val br = 9 * density
            val bx = width - br
            val by = br
            canvas.drawCircle(bx, by, br, badgePaint)
            canvas.drawText(activeCount.toString(), bx, by - (badgeTextPaint.ascent() + badgeTextPaint.descent()) / 2, badgeTextPaint)
        }
    }

    /** Same arrow and tray as the app icon, drawn from its 108-unit design grid. */
    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val s = radius * 0.8f / 30f
        fun x(v: Float) = cx + (v - 54f) * s
        fun y(v: Float) = cy + (v - 54f) * s
        iconPath.reset()
        iconPath.moveTo(x(50.5f), y(36f))
        iconPath.lineTo(x(57.5f), y(36f))
        iconPath.lineTo(x(57.5f), y(50f))
        iconPath.lineTo(x(65f), y(50f))
        iconPath.lineTo(x(54f), y(62f))
        iconPath.lineTo(x(43f), y(50f))
        iconPath.lineTo(x(50.5f), y(50f))
        iconPath.close()
        iconPath.addRect(x(41f), y(66f), x(67f), y(71f), Path.Direction.CW)
        canvas.drawPath(iconPath, iconPaint)
    }

    private fun drawTick(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val r = radius * 0.45f
        iconPath.reset()
        iconPath.moveTo(cx - r, cy)
        iconPath.lineTo(cx - r * 0.3f, cy + r * 0.7f)
        iconPath.lineTo(cx + r, cy - r * 0.6f)
        canvas.drawPath(iconPath, checkPaint)
    }
}
