package com.videograb.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.videograb.app.Quality

/** Asks which quality to download. [showVideoQualities] is false for direct files that only have one quality. */
@Composable
fun QualityDialog(
    title: String,
    subtitle: String? = null,
    showVideoQualities: Boolean = true,
    onDismiss: () -> Unit,
    onConfirm: (Quality) -> Unit,
) {
    val options = if (showVideoQualities) Quality.entries.toList() else listOf(Quality.BEST, Quality.AUDIO)
    var selected by remember { mutableStateOf(Quality.BEST) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(title, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
        },
        text = {
            Column {
                options.forEach { q ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { selected = q }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = selected == q, onClick = { selected = q })
                        Text(if (!showVideoQualities && q == Quality.BEST) "Video (original)" else q.label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(selected) }) { Text("Download") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
