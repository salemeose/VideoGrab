package com.videograb.app.bubble

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.videograb.app.Downloads
import com.videograb.app.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Keeps the floating bubble on screen over other apps.
 * Tapping it opens [LinkPanel]; the ring around it shows download progress.
 */
class BubbleService : LifecycleService() {

    companion object {
        private const val ACTION_STOP = "com.videograb.app.action.STOP_BUBBLE"
        private const val CHANNEL = "bubble"
        private const val NOTIFICATION_ID = 4242
        private const val PREFS = "bubble"

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running

        fun canShow(context: Context) = Settings.canDrawOverlays(context)

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, BubbleService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, BubbleService::class.java))
        }
    }

    private lateinit var windowManager: WindowManager
    private var bubble: BubbleView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panel: LinkPanel? = null
    private var activeJobs: List<WorkInfo> = emptyList()
    private var previouslyActive: Set<java.util.UUID> = emptySet()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        goForeground()

        if (!canShow(this)) {
            stopSelf()
            return
        }
        showBubble()
        _running.value = true

        lifecycleScope.launch {
            WorkManager.getInstance(this@BubbleService)
                .getWorkInfosByTagFlow(Downloads.TAG)
                .collect { onJobsChanged(it) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        _running.value = false
        super.onDestroy()
    }

    // ---------- Bubble ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 0)
            y = prefs.getInt("y", (resources.displayMetrics.heightPixels * 0.35f).toInt())
        }

        val view = BubbleView(this)
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false

        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    downRawX = event.rawX; downRawY = event.rawY
                    dragging = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) dragging = true
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = (startY + dy.toInt()).coerceAtLeast(0)
                        windowManager.updateViewLayout(v, params)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    if (dragging) snapToEdge(v, params) else if (event.actionMasked == MotionEvent.ACTION_UP) togglePanel()
                }
            }
            true
        }

        windowManager.addView(view, params)
        bubble = view
        bubbleParams = params
    }

    /** Slides the bubble to the nearest side of the screen and remembers where it is. */
    private fun snapToEdge(view: View, params: WindowManager.LayoutParams) {
        val screenWidth = resources.displayMetrics.widthPixels
        val target = if (params.x + view.width / 2 < screenWidth / 2) 0 else screenWidth - view.width
        ValueAnimator.ofInt(params.x, target).apply {
            duration = 180
            addUpdateListener {
                params.x = it.animatedValue as Int
                if (view.isAttachedToWindow) windowManager.updateViewLayout(view, params)
            }
            start()
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putInt("x", target).putInt("y", params.y).apply()
    }

    // ---------- Panel ----------

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun openPanel() {
        val margin = (16 * resources.displayMetrics.density).toInt()
        val view = LinkPanel(
            context = this,
            onClose = { closePanel() },
            onOpenApp = {
                closePanel()
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_OPEN_DOWNLOADS, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            },
            onHideBubble = { stopSelf() },
        )
        val params = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - margin * 2,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Focusable (so you can type and so the clipboard can be read), dims what's behind,
            // and reports taps outside so the card can close.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.45f
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
        }
        windowManager.addView(view, params)
        view.showJobs(activeJobs)
        panel = view
    }

    private fun closePanel() {
        panel?.let { runCatching { windowManager.removeView(it) } }
        panel = null
    }

    // ---------- Progress ----------

    private fun onJobsChanged(infos: List<WorkInfo>) {
        val active = infos.filter {
            it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.BLOCKED
        }
        activeJobs = active

        val running = active.filter { it.state == WorkInfo.State.RUNNING }
        val percents = running.map { it.progress.getInt(Downloads.KEY_PROGRESS, -1) }.filter { it >= 0 }
        bubble?.let { b ->
            b.activeCount = active.size
            b.percent = if (percents.isEmpty()) -1 else percents.average().toInt()
        }

        // A job that was active a moment ago and has now succeeded: show a tick.
        val justFinished = infos.any { it.id in previouslyActive && it.state == WorkInfo.State.SUCCEEDED }
        if (justFinished) bubble?.flashDone()
        previouslyActive = active.map { it.id }.toSet()

        panel?.showJobs(active)
    }

    // ---------- Notification (Android requires one while the bubble is shown) ----------

    private fun goForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating bubble", NotificationManager.IMPORTANCE_MIN)
        )
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, BubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("VideoGrab bubble is on")
            .setContentText("Tap the bubble to download a copied link.")
            .setContentIntent(openIntent)
            .addAction(0, "Turn off", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()

        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }
}
