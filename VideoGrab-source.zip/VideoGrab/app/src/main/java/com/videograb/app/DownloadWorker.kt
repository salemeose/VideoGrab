package com.videograb.app

import android.content.ContentValues
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.WorkInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Everything needed to start one download. */
data class DownloadJob(
    val url: String,
    val title: String,
    val quality: Quality,
    val referer: String? = null,
    val userAgent: String? = null,
    val cookies: String? = null,
)

object Downloads {
    const val TAG = "videograb_download"
    const val KEY_URL = "url"
    const val KEY_TITLE = "title"
    const val KEY_QUALITY = "quality"
    const val KEY_REFERER = "referer"
    const val KEY_UA = "ua"
    const val KEY_COOKIES = "cookies"
    const val KEY_PROGRESS = "progress"
    const val KEY_DETAIL = "detail"
    const val KEY_FILE_URI = "file_uri"
    const val KEY_FILE_NAME = "file_name"
    const val KEY_ERROR = "error"
    const val KEY_SIZE = "size"

    // Tags store the title and link so the Downloads screen can show and retry jobs.
    const val TITLE_TAG_PREFIX = "title:"
    const val URL_TAG_PREFIX = "url:"
    const val QUALITY_TAG_PREFIX = "quality:"

    fun enqueue(context: Context, job: DownloadJob): UUID {
        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(
                workDataOf(
                    KEY_URL to job.url,
                    KEY_TITLE to job.title,
                    KEY_QUALITY to job.quality.name,
                    KEY_REFERER to job.referer,
                    KEY_UA to job.userAgent,
                    // Android limits job data to 10 KB, so very large cookie sets are left out.
                    KEY_COOKIES to job.cookies?.takeIf { it.length < 6000 },
                )
            )
            .addTag(TAG)
            .addTag(TITLE_TAG_PREFIX + job.title.take(200))
            .addTag(URL_TAG_PREFIX + job.url.take(1000))
            .addTag(QUALITY_TAG_PREFIX + job.quality.name)
            .build()
        // Each job gets its own name so many downloads can run side by side.
        WorkManager.getInstance(context)
            .enqueueUniqueWork(request.id.toString(), ExistingWorkPolicy.KEEP, request)
        return request.id
    }

    fun cancel(context: Context, id: UUID) {
        WorkManager.getInstance(context).cancelWorkById(id)
    }

    fun clearFinished(context: Context) {
        WorkManager.getInstance(context).pruneWork()
    }

    /** Best title for a job: the looked-up one if known, otherwise the one it was started with. */
    fun titleOf(info: WorkInfo): String =
        info.progress.getString(KEY_TITLE)
            ?: info.outputData.getString(KEY_TITLE)
            ?: info.tags.firstOrNull { it.startsWith(TITLE_TAG_PREFIX) }?.removePrefix(TITLE_TAG_PREFIX)
            ?: "Video"
}

class DownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val notificationId = id.hashCode()
    private val processId = id.toString()

    override suspend fun doWork(): Result {
        val url = inputData.getString(Downloads.KEY_URL) ?: return Result.failure()
        var title = inputData.getString(Downloads.KEY_TITLE) ?: url
        val quality = runCatching { Quality.valueOf(inputData.getString(Downloads.KEY_QUALITY)!!) }
            .getOrDefault(Quality.BEST)

        setForeground(foregroundInfo(title, -1, "Starting…"))
        setProgress(workDataOf(Downloads.KEY_TITLE to title, Downloads.KEY_PROGRESS to -1, Downloads.KEY_DETAIL to "Starting…"))

        // Links sent from the bubble arrive without a title, so look the real one up first.
        if (title == url) {
            runCatching { Engine.lookUpTitle(applicationContext, url) }.getOrNull()?.let { title = it }
            setProgress(workDataOf(Downloads.KEY_TITLE to title, Downloads.KEY_PROGRESS to -1, Downloads.KEY_DETAIL to "Starting…"))
        }

        val workDir = File(applicationContext.getExternalFilesDir(null), "tmp/$processId")
        workDir.mkdirs()

        return try {
            Engine.ensureReady(applicationContext)
            runYtDlp(url, title, quality, workDir)

            // A link with several videos produces several files: keep every one of them.
            val files = workDir.listFiles()
                ?.filter { f ->
                    f.isFile && listOf(".part", ".ytdl", ".temp").none { f.name.endsWith(it) } && f.length() > 0
                }
                ?.sortedBy { it.name }
                .orEmpty()
            if (files.isEmpty()) throw IllegalStateException("The download finished but no file was produced.")

            val savedUris = withContext(Dispatchers.IO) { files.map { saveToDownloads(it) } }
            val totalBytes = files.sumOf { it.length() }
            val summary = if (files.size == 1) "Saved to Downloads/VideoGrab"
            else "${files.size} files saved to Downloads/VideoGrab"
            Notifications.show(
                applicationContext, notificationId + 1,
                Notifications.finished(applicationContext, title, true, summary)
            )
            Result.success(
                workDataOf(
                    Downloads.KEY_FILE_URI to savedUris.firstOrNull()?.toString(),
                    Downloads.KEY_FILE_NAME to
                        if (files.size == 1) files.first().name else "${files.size} files",
                    Downloads.KEY_TITLE to title,
                    Downloads.KEY_SIZE to totalBytes,
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val message = friendlyError(e)
            Notifications.show(
                applicationContext, notificationId + 1,
                Notifications.finished(applicationContext, title, false, message)
            )
            Result.failure(workDataOf(Downloads.KEY_ERROR to message, Downloads.KEY_TITLE to title))
        } finally {
            workDir.deleteRecursively()
        }
    }

    private suspend fun runYtDlp(url: String, title: String, quality: Quality, workDir: File) = coroutineScope {
        val request = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--no-mtime")
            addOption("-o", File(workDir, "%(title).80B [%(id)s].%(ext)s").absolutePath)
            if (quality.audioOnly) {
                addOption("-x")
                addOption("--audio-format", "mp3")
            } else {
                addOption("-f", quality.format!!)
                addOption("--merge-output-format", "mp4")
            }
            inputData.getString(Downloads.KEY_REFERER)?.let { addOption("--referer", it) }
            inputData.getString(Downloads.KEY_UA)?.let { addOption("--user-agent", it) }
            inputData.getString(Downloads.KEY_COOKIES)?.takeIf { it.isNotBlank() }
                ?.let { addOption("--add-header", "Cookie:$it") }
        }

        var lastUpdate = 0L
        val task = async(Dispatchers.IO) {
            YoutubeDL.getInstance().execute(request, processId) { progress, etaSeconds, _ ->
                val now = System.currentTimeMillis()
                if (now - lastUpdate < 800) return@execute
                lastUpdate = now
                val percent = progress.toInt()
                val detail = if (percent >= 0) "$percent% · ${formatEta(etaSeconds)} left" else "Working…"
                setProgressAsync(
                    workDataOf(Downloads.KEY_TITLE to title, Downloads.KEY_PROGRESS to percent, Downloads.KEY_DETAIL to detail)
                )
                Notifications.show(
                    applicationContext, notificationId,
                    Notifications.progress(applicationContext, title, percent, detail)
                )
            }
        }
        try {
            task.await()
        } catch (e: CancellationException) {
            // The user pressed Cancel: stop the yt-dlp process right away.
            YoutubeDL.getInstance().destroyProcessById(processId)
            throw e
        }
    }

    /** Copies the finished file into the phone's public Downloads/VideoGrab folder. */
    private fun saveToDownloads(file: File): Uri? {
        val mime = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = applicationContext.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoGrab")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Couldn't create the file in Downloads.")
            resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "VideoGrab")
            dir.mkdirs()
            val target = File(dir, file.name)
            file.copyTo(target, overwrite = true)
            android.media.MediaScannerConnection.scanFile(applicationContext, arrayOf(target.absolutePath), arrayOf(mime), null)
            return null
        }
    }

    private fun foregroundInfo(title: String, percent: Int, detail: String): ForegroundInfo {
        val notification = Notifications.progress(applicationContext, title, percent, detail)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notificationId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notificationId, notification)
        }
    }

    private fun formatEta(seconds: Long): String = when {
        seconds <= 0 -> "a moment"
        seconds < 60 -> "${seconds}s"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m"
    }

    private fun friendlyError(e: Exception): String {
        val text = e.message.orEmpty()
        return when {
            "Unsupported URL" in text -> "This site isn't supported. Try opening it in the Browser tab."
            "HTTP Error 403" in text -> "The site refused the download (403). Try updating the engine."
            "Private video" in text || "login" in text.lowercase() -> "This video needs a login or is private."
            "DRM" in text -> "This video is DRM-protected and can't be downloaded."
            text.isBlank() -> "Something went wrong."
            else -> text.lines().lastOrNull { it.isNotBlank() }?.take(200) ?: text.take(200)
        }
    }
}
