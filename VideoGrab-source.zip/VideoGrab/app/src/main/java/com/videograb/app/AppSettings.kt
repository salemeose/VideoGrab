package com.videograb.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Small user settings, saved on the phone. */
object AppSettings {
    private const val PREFS = "settings"
    private const val KEY_TURBO = "turbo"
    private const val KEY_ADBLOCK = "adblock"

    private val _turbo = MutableStateFlow(true)
    val turbo: StateFlow<Boolean> = _turbo

    private val _adBlock = MutableStateFlow(true)
    /** Block ads and trackers in the built-in browser. */
    val adBlock: StateFlow<Boolean> = _adBlock

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        _turbo.value = prefs.getBoolean(KEY_TURBO, true)
        _adBlock.value = prefs.getBoolean(KEY_ADBLOCK, true)
    }

    /**
     * Turbo: downloads each file over up to 16 connections at once (aria2c) and fetches
     * streaming pieces 8 at a time. Much faster on most sites; turn it off if a site misbehaves.
     */
    fun setTurbo(context: Context, on: Boolean) {
        _turbo.value = on
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_TURBO, on).apply()
    }

    fun setAdBlock(context: Context, on: Boolean) {
        _adBlock.value = on
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ADBLOCK, on).apply()
    }
}
