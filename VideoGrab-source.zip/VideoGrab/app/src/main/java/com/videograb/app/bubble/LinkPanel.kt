package com.videograb.app.bubble

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.work.WorkInfo
import com.videograb.app.DownloadJob
import com.videograb.app.Downloads
import com.videograb.app.Quality

/**
 * The small card that opens over whatever app you're in when you tap the bubble.
 * It fills in the link you copied, lets you choose a quality, and lists running downloads.
 * Built with plain Android views because it lives outside the app's own screens.
 */
@SuppressLint("ViewConstructor", "SetTextI18n")
class LinkPanel(
    context: Context,
    private val onClose: () -> Unit,
    private val onOpenApp: () -> Unit,
    private val onHideBubble: () -> Unit,
) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val red = Color.parseColor("#E50914")
    private val black = Color.parseColor("#0B0B0B")
    private val grey = Color.parseColor("#9A9A9A")
    private val fieldColor = Color.parseColor("#1C1C1C")

    private var quality = Quality.BEST
    private var clipboardChecked = false

    private val linkInput = EditText(context)
    private val chips = mutableMapOf<Quality, TextView>()
    private val jobsHeader = TextView(context)
    private val jobsList = LinearLayout(context)

    init {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
            background = rounded(black, dp(20).toFloat(), stroke = red)
        }

        card.addView(TextView(context).apply {
            text = "VideoGrab"
            setTextColor(red)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })
        card.addView(TextView(context).apply {
            text = "Copy a video link, then tap Download."
            setTextColor(grey)
            textSize = 13f
            setPadding(0, dp(2), 0, dp(10))
        })

        linkInput.apply {
            hint = "Paste a video link"
            setHintTextColor(grey)
            setTextColor(Color.WHITE)
            textSize = 14f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(fieldColor, dp(12).toFloat())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) { startDownload(); true } else false
            }
        }
        card.addView(linkInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Quality chips
        val chipRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, dp(4))
        }
        listOf(Quality.BEST to "Best", Quality.P720 to "720p", Quality.AUDIO to "MP3").forEach { (q, label) ->
            val chip = TextView(context).apply {
                text = label
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener { selectQuality(q) }
            }
            chips[q] = chip
            chipRow.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { marginEnd = dp(8) })
        }
        card.addView(chipRow)
        selectQuality(Quality.BEST)

        // Paste + Download buttons
        val buttons = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(4))
        }
        buttons.addView(button("Paste", filled = false) { fillFromClipboard(force = true) },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) })
        buttons.addView(button("Download", filled = true) { startDownload() },
            LinearLayout.LayoutParams(0, dp(44), 2f))
        card.addView(buttons)

        // Running downloads
        jobsHeader.apply {
            text = "Downloading"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(4))
            visibility = View.GONE
        }
        card.addView(jobsHeader)
        jobsList.orientation = LinearLayout.VERTICAL
        card.addView(jobsList)

        // Footer links
        val footer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(8), 0, 0)
        }
        footer.addView(textLink("Open app") { onOpenApp() })
        footer.addView(textLink("Hide bubble") { onHideBubble() })
        card.addView(footer)

        addView(card, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    // Android only lets an app read the clipboard while one of its windows has focus,
    // so we read it the moment this card gains focus.
    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (hasWindowFocus && !clipboardChecked) {
            clipboardChecked = true
            fillFromClipboard(force = false)
        }
    }

    // Back button closes the card.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
            onClose()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // Tapping outside the card closes it.
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_OUTSIDE) {
            onClose()
            return true
        }
        return super.onTouchEvent(event)
    }

    /** Called by the bubble service whenever download progress changes. */
    fun showJobs(active: List<WorkInfo>) {
        jobsList.removeAllViews()
        jobsHeader.visibility = if (active.isEmpty()) View.GONE else View.VISIBLE
        active.take(4).forEach { info ->
            val percent = info.progress.getInt(Downloads.KEY_PROGRESS, -1)
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(4), 0, dp(6))
            }
            val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(TextView(context).apply {
                text = Downloads.titleOf(info)
                setTextColor(Color.WHITE)
                textSize = 12f
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(TextView(context).apply {
                text = when {
                    info.state != WorkInfo.State.RUNNING -> "Waiting"
                    percent >= 0 -> "$percent%"
                    else -> "…"
                }
                setTextColor(grey)
                textSize = 12f
                setPadding(dp(8), 0, dp(8), 0)
            })
            top.addView(TextView(context).apply {
                text = "✕"
                setTextColor(red)
                textSize = 14f
                setPadding(dp(6), 0, dp(2), 0)
                setOnClickListener { Downloads.cancel(context, info.id) }
            })
            row.addView(top)
            row.addView(ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                isIndeterminate = percent < 0
                progress = percent.coerceAtLeast(0)
                progressTintList = android.content.res.ColorStateList.valueOf(red)
                indeterminateTintList = android.content.res.ColorStateList.valueOf(red)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#4A0A0D"))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)))
            jobsList.addView(row)
        }
    }

    private fun fillFromClipboard(force: Boolean) {
        val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = runCatching { clip.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString() }.getOrNull()
        val link = text?.let { URL_REGEX.find(it)?.value }
        when {
            link != null -> { linkInput.setText(link); linkInput.setSelection(link.length) }
            force -> Toast.makeText(context, "No link found in what you copied.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDownload() {
        val link = URL_REGEX.find(linkInput.text.toString())?.value
        if (link == null) {
            Toast.makeText(context, "That doesn't look like a link.", Toast.LENGTH_SHORT).show()
            return
        }
        // The title starts as the link; the download job looks up the real title.
        Downloads.enqueue(context, DownloadJob(url = link, title = link, quality = quality))
        Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show()
        linkInput.setText("")
        onClose()
    }

    private fun selectQuality(q: Quality) {
        quality = q
        chips.forEach { (key, chip) ->
            val on = key == q
            chip.setTextColor(if (on) Color.WHITE else grey)
            chip.background = rounded(if (on) red else fieldColor, dp(16).toFloat())
        }
    }

    private fun button(label: String, filled: Boolean, onClick: () -> Unit) = TextView(context).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) Color.WHITE else red)
        background = if (filled) rounded(red, dp(12).toFloat()) else rounded(black, dp(12).toFloat(), stroke = red)
        setOnClickListener { onClick() }
    }

    private fun textLink(label: String, onClick: () -> Unit) = TextView(context).apply {
        text = label
        setTextColor(grey)
        textSize = 13f
        setPadding(dp(12), dp(8), dp(4), dp(4))
        setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, radius: Float, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (stroke != null) setStroke(dp(1), stroke)
    }

    companion object {
        private val URL_REGEX = Regex("""https?://\S+""")
    }
}
