# VideoGrab

An Android video downloader with three tabs:

- **Browser**: browse any site. Video files the page loads (mp4, webm, HLS/m3u8, DASH) are listed under the Download button. "Smart mode" sends the page to yt-dlp.
- **Paste link**: paste or share a link, VideoGrab looks it up with yt-dlp, you pick a quality (best, 1080p, 720p, 480p, or MP3 audio).
- **Downloads**: progress, cancel, retry and open. Downloads keep running in the background with a notification and are saved to `Downloads/VideoGrab`.

Use it only for videos you own or have permission to save. DRM-protected and login-only content isn't supported.

## Building the APK without installing anything

1. Make a free account at github.com and create a new repository (tick "Add a README file").
2. **Add file → Upload files**, upload `VideoGrab-source.zip`, then press **Commit changes**.
3. **Add file → Create new file**, name it `.github/workflows/build.yml`, paste in the contents of `build.yml`, then press **Commit changes**.
4. Open the **Actions** tab and wait about 10 minutes for the green tick.
5. Open **Releases** on the repository's main page and download `VideoGrab.apk` on your phone. Install it, allowing "install unknown apps" for your browser when Android asks.

If the build shows a red ✗, open it, copy the error text and send it to Claude to fix.

## Building on a computer (optional)

Open this folder in Android Studio and press Run.

## How it works

- `Engine.kt` sets up and updates yt-dlp (via youtubedl-android) and FFmpeg.
- `DownloadWorker.kt` runs each download as a WorkManager job, then copies the file into Downloads.
- `ui/BrowserScreen.kt` watches the WebView's network requests for media files.
- `ui/LinkScreen.kt` and `ui/DownloadsScreen.kt` are the other two tabs.
